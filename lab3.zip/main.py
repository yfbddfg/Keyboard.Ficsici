import check_file as c_f 
import write_count_fing as w_c_fing
import write_count_fine as w_c_fine
import write_count_two_sym as w_c_ts
import write_count_two_sym_20 as w_c_ts_20
import draw_gist as dg
#import draw_gist_fing as dr_fing
#import draw_gist_fine as dr_fine 
#import draw_gist_two_sym as dr_two_sym


if __name__ == "__main__":

#Touches for fingers
    finger_dict_qwerty = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                          "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}
    
    finger_dict_zubachew = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                            "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}

#Fine for fingers
    fine_dict_qwerty = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                          "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}

    fine_dict_zubachew = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                            "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}
#Convenient two-letter combinations qwerty

    two_letter_dict_qwerty = {"фы": 0, "фв": 0, "фа": 0, "ыв": 0, "ыа": 0, "ва": 0,
                             "жд": 0, "жл": 0, "жо": 0, "дл": 0, "до": 0, "ло": 0}

#Convenient two-letter combinations zubachew
    two_letter_dict_zubachew = {"ги": 0, "ге": 0, "го": 0, "ие": 0, "ио": 0, "ео": 0,
                            "зн": 0, "зс": 0, "зт": 0, "нс": 0, "нт": 0, "ст": 0}

#Two-letter combinations top 20 
    
    two_letter_dict_t20 = {}

#

    strs = c_f.check_file("final_test.txt") + c_f.check_file("voina-i-mir.txt")

    finger_dict_qwerty, finger_dict_zubachew = w_c_fing.write_count_fing(strs, \
                            finger_dict_qwerty, finger_dict_zubachew)

    fine_dict_qwerty, fine_dict_zubachew = w_c_fine.write_count_fine(strs, \
                            fine_dict_qwerty, fine_dict_zubachew)

    two_letter_dict_qwerty, two_letter_dict_zubachew = w_c_ts.write_count_two_sym(\
                    strs, two_letter_dict_qwerty, two_letter_dict_zubachew)

    two_letter_dict_t20 = w_c_ts_20.write_count_two_sym_20(strs, two_letter_dict_t20)

#For touches fingers готов
    print("Touches")
    print("QWERTY:", finger_dict_qwerty)
    print("Zubachew:", finger_dict_zubachew)

#    dr_fing.draw_gist_fing(finger_dict_qwerty, finger_dict_zubachew)

#For fine fingers делаем
    print("Fines")
    print("QWERTY:", fine_dict_qwerty)
    print("Zubachew:", fine_dict_zubachew)

#    dr_fine.draw_gist_fine(fine_dict_qwerty, fine_dict_zubachew)

#For Two-letter combinations делаем
    print("Two-letter_qwerty")
    print("QWERTY:", two_letter_dict_qwerty)
    print("Two-letter_zubachew")
    print("Zubachew:", two_letter_dict_zubachew)
                                                                 
#    dr_two_sym.draw_gist_two_sym_qwerty(two_letter_dict_qwerty)
#    dr_two_sym.draw_gist_two_sym_zubachew(two_letter_dict_zubachew)

#For two-letter combinations top 20
    print("Top20")
    print("Top20:", two_letter_dict_t20)

#делаем    w_c_ts_20.draw_gist_two_sym_20(two_letter_dict_t20)

    dg.draw_gist(finger_dict_qwerty, finger_dict_zubachew, fine_dict_qwerty, fine_dict_zubachew, two_letter_dict_qwerty, two_letter_dict_zubachew, two_letter_dict_t20)

