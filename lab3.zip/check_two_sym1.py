
strs="123АбгабвбвБвввббФа1"

syllabary = {}

def check_two_sym( teststring , syllabarydict ):
    dict_spec_chrs =  [' ', '1', '!', '2', '"', '3',\
                     '№', '4', ';', '5', '%', '6',\
                     ':', '7', '?', '8', '*', '9',\
                     '(', '0', ')', '.', ',', '-',\
                     '_', '=', '+', '/', '\\', '\n']
    

    for i in range(len(strs) - 1):
        symbol = strs[i].lower()
        nextsymbol = strs[i+1].lower()
        if not ( symbol in dict_spec_chrs ) and not ( nextsymbol in dict_spec_chrs ):
            syll = symbol + nextsymbol
            if syll in syllabarydict:
                syllabarydict[syll] += 1
            else:
                syllabarydict[syll] = 1


check_two_sym(strs, syllabary)

print(syllabary)

outputdict = {key:value for key, value in sorted(syllabary.items(), key = lambda item: item[1], reverse = True)}

print(outputdict)

numberofvals = 5

shortenedoutputdict={}

for row in outputdict:
    shortenedoutputdict[row] = outputdict[row]
    numberofvals -= 1
    if numberofvals == 0:
        break

print(shortenedoutputdict)
