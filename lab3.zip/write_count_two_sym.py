import check_two_sym as cts


def write_count_two_sym(strs, two_letter_dict_qwerty, two_letter_dict_zubachew):

    for i in range(len(strs) - 1):
        symbol = strs[i].lower()
        nextsymbol = strs[i+1].lower()

        syll = symbol + nextsymbol

        presseddict1 = cts.check_two_sym_qwerty(syll) 
        presseddict2 = cts.check_two_sym_zubachew(syll)

        for fingerkey in presseddict1:
            two_letter_dict_qwerty[fingerkey] += presseddict1[fingerkey]
        for fingerkey in presseddict2:
            two_letter_dict_zubachew[fingerkey] += presseddict2[fingerkey] 

    return two_letter_dict_qwerty, two_letter_dict_zubachew
