# Полный код для построения графиков сравнения нагрузки на пальцы для раскладок ЙЦУКЕН и Zubachew.

# Данные для нагрузки на пальцы (примерные значения)
finger_dict_qwerty = {
    "фы": 150, "фв": 130, "фа": 120,
    "ыв": 140, "ыа": 110, "ва": 100,
    "жд": 90, "жл": 80, "жо": 70,
    "дл": 60, "до": 50, "ло": 40
}

finger_dict_zubachew = {
    "ги": 140, "ге": 120, "го": 100,
    "ие": 110, "ио": 90, "ео": 80,
    "зн": 70, "зс": 60, "зт": 50,
    "нс": 40, "нт": 30, "ст": 20
}

# Названия пальцев
fingers = [
    "Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
    "Указательный (левая)", "Большой", 
    "Указательный (правая)", "Средний (правая)", 
    "Безымянный (правая)", "Мизинец (правая)"
]

# Извлечение данных для графиков
qwerty_values = [finger_dict_qwerty[key] for key in finger_dict_qwerty]
zubachew_values = [finger_dict_zubachew[key] for key in finger_dict_zubachew]

# Построение графиков
import matplotlib.pyplot as plt
import numpy as np

x = np.arange(len(qwerty_values))
width = 0.4

fig, ax = plt.subplots(figsize=(12, 8))
ax.barh(x - width / 2, qwerty_values, width, label='ЙЦУКЕН', color='#ffb3ba')
ax.barh(x + width / 2, zubachew_values, width, label='Zubachew', color='#c9c9ff')

# Оформление графика
ax.set_xlabel('Количество нажатий', fontsize=12)
ax.set_title('Сравнение нагрузки на пальцы в раскладках ЙЦУКЕН и Zubachew', fontsize=14)
ax.set_yticks(x)
ax.set_yticklabels(list(finger_dict_qwerty.keys()), fontsize=10)
ax.legend(fontsize=12)

plt.tight_layout()
plt.savefig('/mnt/data/keyboard_comparison_chart.png')  # Сохраняем изображение
plt.show()