def draw_gists():

    finger_dict_qwerty = {}
    
    finger_dict_zubachew = {}
    
    fingers = [
        "Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
        "Указательный (левая)", "Большой", 
        "Указательный (правая)", "Средний (правая)", 
        "Безымянный (правая)", "Мизинец (правая)"
    ]
    
    qwerty_values = [finger_dict_qwerty[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
    zubachew_values = [finger_dict_zubachew[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
    
    # Создание фигуры с 5 подграфиками (2x3 сетка)
    import matplotlib.pyplot as plt
    import numpy as np
    
    fig, axs = plt.subplots(2, 3, figsize=(18, 12))
    fig.suptitle('Сравнение нагрузки на пальцы и частот двухбуквенных сочетаний', fontsize=16)
    
    # Построение 5 разных графиков
    for i, ax in enumerate(axs.flatten()):
        x = np.arange(len(fingers))
        width = 0.4
    
        # Используем одинаковые данные для всех графиков в качестве примера
        ax.barh(x + width / 2, qwerty_values, width, label='йцукен', color='#ffb3ba')
        ax.barh(x - width / 2, zubachew_values, width, label='zubachew', color='#c9c9ff')
    
        # Настройки графика
        ax.set_xlabel('Количество нажатий', fontsize=10)
        ax.set_title(f'График {i + 1}', fontsize=12)
        ax.set_yticks(x)
        ax.set_yticklabels(fingers, fontsize=8)
        ax.legend(fontsize=9)
        break
    flag = 0
    for i, ax in enumerate(axs.flatten()):
        if flag == 0:
            flag = 1
            continue
    
        x = np.arange(len(fingers))
        width = 0.4
    
        # Используем одинаковые данные для всех графиков в качестве примера
        ax.barh(x + width / 2, qwerty_values, width, label='йцукен', color='#ffb3ba')
        ax.barh(x - width / 2, zubachew_values, width, label='zubachew', color='#c9c9ff')
    
        # Настройки графика
        ax.set_xlabel('Количество нажатий', fontsize=10)
        ax.set_title(f'График {i + 10}', fontsize=12)
        ax.set_yticks(x)
        ax.set_yticklabels(fingers, fontsize=8)
        ax.legend(fontsize=9)
        break
    
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig('five_comparison_charts.png')  # Сохранение графиков
    plt.show()
