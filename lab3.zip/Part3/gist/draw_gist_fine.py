import numpy as np
import matplotlib.pyplot as plt 


def draw_gist_fine(finger_dict_qwerty, finger_dict_zubachew):

    fingers = ["Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
               "Указательный (левая)", "Большой", 
               "Указательный (правая)", "Средний (правая)", 
               "Безымянный (правая)", "Мизинец (правая)"]

    qwerty_values = [finger_dict_qwerty[key] for key in ["lpin", "lb", "lmid",\
            "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
    zubachew_values = [finger_dict_zubachew[key] for key in ["lpin", "lb", "lmid",\
            "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]

    x = np.arange(len(fingers))
    width = 0.4

    _, ax = plt.subplots(figsize=(10, 6))
    ax.barh(x - width/2, qwerty_values, width, label='ЙЦУКЕН', color='#ffb3ba')
    ax.barh(x + width/2, zubachew_values, width, label='Zubachew', color='#c9c9ff')

    ax.set_xlabel('Количество нажатий')
#Здесь штрафы на каждый палец
#    ax.set_title('Сравнение нагрузки на пальцы в раскладках ЙЦУКЕН и Zubachew')
    ax.set_yticks(x)
    ax.set_yticklabels(fingers)
    ax.legend()

    plt.tight_layout()
    plt.show()

