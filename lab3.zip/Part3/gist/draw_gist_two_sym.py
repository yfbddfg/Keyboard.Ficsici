import numpy as np
import matplotlib.pyplot as plt 


def draw_gist_two_sym_qwerty(finger_dict_qwerty):

#    fingers = ["Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
#               "Указательный (левая)", "Большой", 
#               "Указательный (правая)", "Средний (правая)", 
#               "Безымянный (правая)", "Мизинец (правая)"]
#
#    qwerty_values = [finger_dict_qwerty[key] for key in ["фы", "фв",\
#            "фа", "ыв", "ыа", "ва", "жд", "жл", "жо", "дл", "до", "ло"]]
#
#    x = np.arange(len(fingers))
#    width = 0.4
#
#    _, ax = plt.subplots(figsize=(10, 6))
#    ax.barh(x - width/2, qwerty_values, width, label='ЙЦУКЕН', color='#ffb3ba')
#
#    ax.set_xlabel('Количество нажатий')
#    ax.set_title('Сравнение нагрузки на пальцы в раскладках ЙЦУКЕН и Zubachew')
#    ax.set_yticks(x)
#    ax.set_yticklabels(fingers)
#    ax.legend()

    plt.tight_layout()
    plt.show()

def draw_gist_two_sym_zubachew(finger_dict_zubachew):

#    fingers = ["Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
#               "Указательный (левая)", "Большой", 
#               "Указательный (правая)", "Средний (правая)", 
#               "Безымянный (правая)", "Мизинец (правая)"]
#
#    zubachew_values = [finger_dict_zubachew[key] for key in ["ги", "ге",\
#            "го", "ие", "ио", "ео", "зн", "зс", "зт", "нс", "нт", "ст"]]
#
#    x = np.arange(len(fingers))
#    width = 0.4
#
#    _, ax = plt.subplots(figsize=(10, 6))
#    ax.barh(x + width/2, zubachew_values, width, label='Zubachew', color='#c9c9ff')
#
#    ax.set_xlabel('Количество нажатий')
#    ax.set_title('Сравнение нагрузки на пальцы в раскладках ЙЦУКЕН и Zubachew')
#    ax.set_yticks(x)
#    ax.set_yticklabels(fingers)
#    ax.legend()

    plt.tight_layout()
    plt.show()

