def draw_gist(finger_dict_qwerty, finger_dict_zubachew, fine_dict_qwerty, fine_dict_zubachew, two_letter_dict_qwerty, two_letter_dict_zubachew, two_letter_dict_t20):

#rows
     fingers = [
         "Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
         "Указательный (левая)", "Большой", 
         "Указательный (правая)", "Средний (правая)", 
         "Безымянный (правая)", "Мизинец (правая)"]

     two_letter_qwerty_conv = ["фы", "фв", "фа", "ыв", "ыа", "ва", "жд", "жл", "жо", "дл", "до", "ло"]

     two_letter_zubachew_conv = ["ги", "ге", "го", "ие", "ио", "ео", "зн", "зс", "зт", "нс", "нт", "ст"]

     two_letter_top20 = []
#values of rows
#touches     
     fing_qwerty_values = [finger_dict_qwerty[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
     fing_zubachew_values = [finger_dict_zubachew[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
     
#fines
     fine_qwerty_values = [fine_dict_qwerty[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
     fine_zubachew_values = [fine_dict_zubachew[key] for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]

#Convenient two-letter combinations qwerty
     two_letter_qwerty_values = [two_letter_dict_qwerty[key] for key in ["фы", "фв", "фа", "ыв", "ыа", "ва", "жд", "жл", "жо", "дл", "до", "ло"]]

#Convenient two-letter combinations zubachew
     two_letter_zubachew_values = [two_letter_dict_zubachew[key] for key in ["ги", "ге", "го", "ие", "ио", "ео", "зн", "зс", "зт", "нс", "нт", "ст"]]

#Two-letter combinations top 20
     two_letter_top20_values = [value for _, value in two_letter_dict_t20.items()]
     two_letter_top20 = [key for key, _ in two_letter_dict_t20.items()]

# Создание фигуры с 5 подграфиками (2x3 сетка)
     import matplotlib.pyplot as plt
     import numpy as np
     
     fig, axs = plt.subplots(2, 3, figsize=(18, 12))
     fig.suptitle('Сравнение нагрузки на пальцы и частот двухбуквенных сочетаний', fontsize=16)
     
# Построение 5 разных графиков
#Fing
     for i, ax in enumerate(axs.flatten()):
         x = np.arange(len(fingers))
         width = 0.4
     
         ax.barh(x + width / 2, fing_qwerty_values, width, label='йцукен', color='#ffb3ba')
         ax.barh(x - width / 2, fing_zubachew_values, width, label='zubachew', color='#c9c9ff')
     
         # Настройки графика
         ax.set_xlabel('Количество нажатий', fontsize=10)
         ax.set_title(f'Нагрузка на пальцы', fontsize=12)
         ax.set_yticks(x)
         ax.set_yticklabels(fingers, fontsize=8)
         ax.legend(fontsize=9)
         break
#Fine
     for i, ax in enumerate(axs.flatten()):
         if i != 1:
             continue
     
         x = np.arange(len(fingers))
         width = 0.4
     
         ax.barh(x + width / 2, fine_qwerty_values, width, label='йцукен', color='#ffb3ba')
         ax.barh(x - width / 2, fine_zubachew_values, width, label='zubachew', color='#c9c9ff')
     
         # Настройки графика
         ax.set_xlabel('Количество нажатий', fontsize=10)
         ax.set_title(f'Штрафы на пальцы', fontsize=12)
         ax.set_yticks(x)
         ax.set_yticklabels(fingers, fontsize=8)
         ax.legend(fontsize=9)
         break

#Convenient two-letter combinations qwerty
     for i, ax in enumerate(axs.flatten()):
          if i != 2:
              continue
      
          x = np.arange(len(two_letter_qwerty_conv))
          width = 0.4
      
          ax.barh(x + width / 2, two_letter_qwerty_values, width, label='йцукен', color='#ffb3ba')
      
          ax.set_xlabel('Количество нажатий', fontsize=10)
          ax.set_title(f'Удобные двухвуквенные сочетания расскладки йцукен', fontsize=10)
          ax.set_yticks(x)
          ax.set_yticklabels(two_letter_qwerty_conv, fontsize=8)
          ax.legend(fontsize=9)
          break

#Convenient two-letter combinations zubachew
     for i, ax in enumerate(axs.flatten()):
         if i != 3:
             continue
     
         x = np.arange(len(two_letter_zubachew_conv))
         width = 0.4
     
         ax.barh(x - width / 2, two_letter_zubachew_values, width, label='zubachew', color='#c9c9ff')
     
         # Настройки графика
         ax.set_xlabel('Количество нажатий', fontsize=10)
         ax.set_title(f'Удобные двухбуквенные сочетания раскладки zubachew', fontsize=12)
         ax.set_yticks(x)
         ax.set_yticklabels(two_letter_zubachew_conv, fontsize=8)
         ax.legend(fontsize=9)
         break

#Two-letter combinations top 20
     for i, ax in enumerate(axs.flatten()):
         if i != 4:
             continue
     
         x = np.arange(len(two_letter_top20))
         width = 0.4
     
         # Используем одинаковые данные для всех графиков в качестве примера
         ax.barh(x + width / 2, two_letter_top20_values, width, label='Двухбуквенные сочетания', color='#ffb3ba')
     
         # Настройки графика
         ax.set_xlabel('Количество нажатий', fontsize=10)
         ax.set_title(f'Top 20 часто используемых двухбуквенных сочетаний', fontsize=12)
         ax.set_yticks(x)
         ax.set_yticklabels(two_letter_top20, fontsize=8)
         ax.legend(fontsize=9)
         break

     plt.tight_layout(rect=[0, 0, 1, 0.95])
     plt.savefig('five_comparison_charts.png')  # Сохранение графиков
     plt.show()
