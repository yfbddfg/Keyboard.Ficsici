
def check_two_sym_qwerty(letter):

    if letter in ["фы"]:
        return {"фы": 1}

    if letter in ["фв"]:
        return {"фв": 1}

    if letter in ["фа"]:
        return {"фа": 1}

    if letter in ["ыв"]:
        return {"ыв": 1}

    if letter in ["ыа"]:
        return {"ыа": 1}

    if letter in ["ва"]:
        return {"ва": 1}
    
    if letter in ["жд"]:
        return {"жд": 1}

    if letter in ["жл"]:
        return {"жл": 1}

    if letter in ["жо"]:
        return {"жо": 1}

    if letter in ["дл"]:
        return {"дл": 1}

    if letter in ["до"]:
        return {"до": 1}

    if letter in ["ло"]:
        return {"ло": 1}

    return{"фы": 0}

def check_two_sym_zubachew(letter):

    if letter in ["ги"]:
        return {"ги": 1}

    if letter in ["ге"]:
        return {"ге": 1}

    if letter in ["го"]:
        return {"го": 1}

    if letter in ["ие"]:
        return {"ие": 1}

    if letter in ["ио"]:
        return {"ио": 1}

    if letter in ["ео"]:
        return {"ео": 1}
    
    if letter in ["зн"]:
        return {"зн": 1}

    if letter in ["зс"]:
        return {"зс": 1}

    if letter in ["зт"]:
        return {"зт": 1}

    if letter in ["нс"]:
        return {"нс": 1}

    if letter in ["нт"]:
        return {"нт": 1}

    if letter in ["ст"]:
        return {"ст": 1}
    
    return {"ги": 1}
