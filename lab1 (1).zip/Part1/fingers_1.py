
lasthand="right"


def checkfinger(letter):
    global lasthand
    if letter in ["`","1","q","a","z"]:
        lasthand="left"
        return {"lpin": 1}

    if letter in ["~","!","Q","A","Z"]:
        lasthand="left"
        return {"lpin": 1} #, "lb": 1}

    if letter in ["2","w","s","x"]:
        lasthand="left"
        return {"lb": 1}

    if letter in ['@',"W","S","X"]:
        lasthand="left"
        return {"lb":1} #,"lpin": 1}

    if letter in ["3","e","d","c"]:
        lasthand="left"
        return {"lmid": 1}

    if letter in ['#',"E","D","C"]:
        lasthand="left"
        return {"lmid":1} #,"lpin": 1}
    
    if letter in ["4","5","r","t","f","g","v","b"]:
        lasthand="left"
        return {"lpoint": 1}

    if letter in ["$","%","R","T","F","G","V","B"]:
        lasthand="left"
        return {"lpoint": 1} #, "lpin": 1}

    if letter in ["6","7","y","u","h","j","n","m"]:
        lasthand="right"
        return {"rpoint": 1}

    if letter in ["^","&","Y","U","H","J","N","M"]:
        lasthand="right"
        return {"rpoint": 1} #, "lpin": 1}

    if letter in ["8","i","k",","]:
        lasthand="right"
        return {"rmid": 1}

    if letter in ['*',"I","K","<"]:
        lasthand="right"
        return {"rmid":1}# ,"lpin": 1}

    if letter in ["9","o","l","."]:
        lasthand="right"
        return {"rb": 1}

    if letter in ['(',"O","L",">"]:
        lasthand="right"
        return {"rb":1}# ,"lpin": 1}

    if letter in ["0","-","=","p","[","]",";","'", "/"]:
        lasthand="right"
        return {"rpin": 1}

    if letter in [")","_","+","P","{","}",":",'"',"?"]:
        lasthand="right"
        return {"rpin": 1}#, "lpin": 1}
    
    if letter == "\n":
        return {"rpin":1}

    if letter == " ":
        if lasthand == "right":
            return {"lthmb": 1}
        else:
            return {"rthmb": 1}


fingerdict = {
        "lpin":0,
        "lb":0,
        "lmid":0,
        "lpoint":0,
        "rpin":0,
        "rb":0,
        "rmid":0,
        "rpoint":0,
        "lthmb":0,
        "rthmb":0
        }

teststr=""

with open("test.txt","r") as file:
    teststr = file.read()

for ch in teststr:
    presseddict = checkfinger(ch)
    for fingerkey in presseddict:
        fingerdict[fingerkey] += presseddict[fingerkey]

print(fingerdict)

sum = 0
for i in fingerdict:
    t = fingerdict[i]
    sum += t

print(sum)
