
lasthand="right"


def checkfinger(letter):
    global lasthand
    if letter in ["ё","1","ф","г","ш"]:
        lasthand="left"
        return {"lpin": 1}

    if letter in ["Ё","!","Ф","Г","Ш"]:
        lasthand="left"
        return {"lpin": 1, "lb": 1}

    if letter in ["2","ы","и","ь"]:
        lasthand="left"
        return {"lb": 1}

    if letter in ['"',"Ы","И","ъ"]:
        lasthand="left"
        return {"lb":1 ,"lpin": 1}

    if letter in ["3","а","е","ю"]:
        lasthand="left"
        return {"lmid": 1}

    if letter in ['№',"А","Е","Ю"]:
        lasthand="left"
        return {"lmid":1 ,"lpin": 1}
    
    if letter in ["4","5","я",",","о","у",".","э"]:
        lasthand="left"
        return {"lpoint": 1}

    if letter in [";","%","ъ","ь","Я","О","У","Э"]:
        lasthand="left"
        return {"lpoint": 1, "lpin": 1}

    if letter in ["6","7","й","м","л","т","б","д"]:
        lasthand="right"
        return {"rpoint": 1}

    if letter in [":","?","Й","М","Л","Т","Б","Д"]:
        lasthand="right"
        return {"rpoint": 1, "lpin": 1}

    if letter in ["8","р","с","в"]:
        lasthand="right"
        return {"rmid": 1}

    if letter in ['*',"Р","С","В"]:
        lasthand="right"
        return {"rmid":1 ,"lpin": 1}

    if letter in ["9","п","н","к"]:
        lasthand="right"
        return {"rb": 1}

    if letter in ['(',"П","Н","К"]:
        lasthand="right"
        return {"rb":1 ,"lpin": 1}

    if letter in ["0","-","=","х","ц","щ","\\","з","ж","ч"]:
        lasthand="right"
        return {"rpin": 1}

    if letter in [")","_","+","Х","Ц","Щ","/","З","Ж","Ч"]:
        lasthand="right"
        return {"rpin": 1, "lpin": 1}
    
    if letter == "\n":
        return {"rpin":1}

    if letter == " ":
        if lasthand == "right":
            return {"lthmb": 1}
        else:
            return {"rthmb": 1}


fingerdict = {
        "lpin":0,
        "lb":0,
        "lmid":0,
        "lpoint":0,
        "rpin":0,
        "rb":0,
        "rmid":0,
        "rpoint":0,
        "lthmb":0,
        "rthmb":0
        }

teststr=""

with open("test.txt","r") as file:
    teststr = file.read()

for ch in teststr:
    presseddict = checkfinger(ch)
    for fingerkey in presseddict:
        fingerdict[fingerkey] += presseddict[fingerkey]

print(fingerdict)
