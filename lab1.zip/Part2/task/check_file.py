def check_file(test_file):
    result_str = ""
    syms = ['ё', ' ', 'Ё', '1', '!', 'й', 'Й', 'ф', 'Ф', 'я',\
            'Я', '2', '"', 'ц', 'Ц', 'ы', 'Ы', 'ч', 'Ч', '3', \
            '№', 'у', 'У', 'в', 'В', 'с', 'С', '4', ';', 'к', \
            'К', 'а', 'А', 'м', 'М', '5', '%', 'е', 'Е', 'п', \
            'П', 'и', 'И', '6', ':', 'н', 'Н', 'р', 'Р', 'т', \
            'Т', '7', '?', 'г', 'Г', 'о', 'О', 'ь', 'Ь', '8', \
            '*', 'ш', 'Ш', 'л', 'Л', 'б', 'Б', '9', '(', 'щ', \
            'Щ', 'д', 'Д', 'ю', 'Ю', '0', ')', 'з', 'З', 'ж', \
            'Ж', '.', ',', '-', '_', 'х', 'Х', 'э', 'Э', '=', \
            '+', 'ъ', 'Ъ', '/', '\\', '\n']
    with open(test_file, "r") as file_object:
        flag_sym = 0
        for line in file_object:
            for sym in line:
                if not (sym in syms):
                    flag_sym = 1
                    break
            if (flag_sym == 0):
                result_str += line
            flag_sym = 0
    file_object.close()

    return result_str

#strs = check_file("test.txt")
#print(strs)

