import check_file as c_f
import check_finger as c_fi
import draw_gist as dr


if __name__ == "__main__":

    finger_dict_qwerty = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                          "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}
    
    finger_dict_zubachew = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                            "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}

    strs = c_f.check_file("final_test.txt")

    for ch in strs:
        presseddict1 = c_fi.check_finger_zubachew(ch)
        presseddict2 = c_fi.check_finger_qwerty(ch)

        for fingerkey in presseddict1:
            finger_dict_zubachew[fingerkey] += presseddict1[fingerkey]

        for fingerkey in presseddict2:
            finger_dict_qwerty[fingerkey] += presseddict2[fingerkey]

    # Печать значений словарей для проверки
    print("QWERTY:", finger_dict_qwerty)
    print("Zubachew:", finger_dict_zubachew)

    # Построение графика
    dr.draw_gist(finger_dict_zubachew, finger_dict_qwerty)

