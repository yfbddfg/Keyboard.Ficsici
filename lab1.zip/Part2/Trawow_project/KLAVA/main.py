#   Основной исполняемый файл
import check_file as c_f
# import check_file as c_fi: импортируем модуль check_file
# as c_f:  дает модулю короткое имя c_f.
import check_finger as c_fi         # import check_finger as c_fi: импортируем модуль check_finger
# as c_fi: даёт модулю короткое имя c_fi
import draw_gist as dr              #import draw_gist as dr:Импортируем модуль draw_gist
# as dr: даёт модулю короткое имя dr


if __name__ == "__main__":
    # Создается словарь для хранения данных о том, сколько раз использовался каждый палец при печати на раскладке "qwerty" и зубачев.
# Ключи словаря - это имена пальцев:
#        * lpin: мезинец левой руки
#        * lb: безымянный палец левой руки
#        * lmid: средний палец левой руки
#        * lpoint: указательный палец левой руки
#        * rpoint: указательный палец правой руки
#        * rmid: средний палец правой руки
#        * rb: безымянный палец правой руки
#        * rpin: мезинец правой руки
#        * thmb: большой палец


    finger_dict_qwerty = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                          "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}
    
    finger_dict_zubachew = {"lpin": 0, "lb": 0, "lmid": 0, "lpoint": 0,
                            "rpoint": 0, "rmid": 0, "rb": 0, "rpin": 0, "thmb": 0}

    strs = c_f.check_file("final_test.txt")     # вызывается функция check_file из модуля c_f.  
# c_f.check_file:  вызывает функцию check_file с аргументом  final_test.txt,  который указывает имя файла, из которого нужно прочитать данные. 

    for ch in strs:         # В цикле просматриваются все символы переменной strs
        presseddict1 = c_fi.check_finger_zubachew(ch)   # вызываем функцию check_finger_zubachew из модуля c_fi для определения, какие пальцы использовались для нажатия клавиши ch в раскладке "зубачев"
#   результат выполнения функции (где ключи — пальцы, а значения — количество их использований) записываем в переменную presseddict1.
        presseddict2 = c_fi.check_finger_qwerty(ch)     #вызываем функцию check_finger_qwerty из модуля c_fi для определения, какие пальцы использовались для нажатия клавиши ch в раскладке "йцукен"
#   результат выполнения функции (где ключи — пальцы, а значения — количество их использований) записываем в переменную presseddict2.


        for fingerkey in presseddict1:      # В цикле просматриваются все ключи в словаре presseddict1.
            finger_dict_zubachew[fingerkey] += presseddict1[fingerkey]  # увеличивает значение для данного пальца в словаре finger_dict_zubachew на количество его использований для нажатой клавиши ch (полученное из presseddict1).


        for fingerkey in presseddict2:      # В цикле просматриваются все ключи в словаре presseddict2.
            finger_dict_qwerty[fingerkey] += presseddict2[fingerkey]    # увеличивает значение для данного пальца в словаре finger_dict_qwerty на количество его использований для нажатой клавиши ch (полученное из presseddict2).


    # Печать значений словарей для проверки
    print("QWERTY:", finger_dict_qwerty)    # Выводит на экран словарь finger_dict_qwerty, который содержит информацию о количестве нажатий пальцев для раскладки QWERTY.
    print("Zubachew:", finger_dict_zubachew)    # как и у принта выше, выводит словарь finger_dict_zubachew для раскладки Зубачёва.

    # Построение графика
    dr.draw_gist(finger_dict_zubachew, finger_dict_qwerty)  # Вызывает функцию draw_gist из модуля dr, передавая ей два словаря с информацией о количестве нажатий для каждой раскладки. 
    # функция создает график, визуально сравнивающий нагрузку на пальцы для двух раскладок йцукен и zubachew .

