import numpy as np
import matplotlib.pyplot as plt

def draw_gist(finger_dict_qwerty, finger_dict_zubachew, filename="finger_comparison.png"):
    # Создание списка пальцев
    fingers = ["Мизинец (левая)", "Безымянный (левая)", "Средний (левая)", 
               "Указательный (левая)", "Большой", 
               "Указательный (правая)", "Средний (правая)", 
               "Безымянный (правая)", "Мизинец (правая)"]

    # Извлечение данных для графика
    qwerty_values = [finger_dict_qwerty.get(key, 0) for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]
    zubachew_values = [finger_dict_zubachew.get(key, 0) for key in ["lpin", "lb", "lmid", "lpoint", "thmb", "rpoint", "rmid", "rb", "rpin"]]

    # Позиции для столбцов гистограммы
    x = np.arange(len(fingers))
    width = 0.4  # ширина столбцов

    # Создание фигуры и оси
    _, ax = plt.subplots(figsize=(10, 6))
    ax.barh(x - width/2, qwerty_values, width, label='ЙЦУКЕН', color='#ffb3ba')
    ax.barh(x + width/2, zubachew_values, width, label='Zubachew', color='#c9c9ff')

    # Настройки графика
    ax.set_xlabel('Количество нажатий')
    ax.set_title('Сравнение нагрузки на пальцы в раскладках ЙЦУКЕН и Zubachew')
    ax.set_yticks(x)
    ax.set_yticklabels(fingers)
    ax.legend()

    # Сохранение графика в файл
    plt.tight_layout()
    plt.savefig(filename)  # Сохранение изображения в файл
    print(f"График сохранён как {filename}")

    plt.show()  # Отображение графика

# Тестирование функции с разными данными
def test_draw_gist():
    # Пример данных для тестов
    test_cases = [
        (  # Тест 1
            {
                "lpin": 5, "lb": 7, "lmid": 10, "lpoint": 12, "thmb": 20,
                "rpoint": 15, "rmid": 10, "rb": 8, "rpin": 6
            },
            {
                "lpin": 6, "lb": 8, "lmid": 11, "lpoint": 13, "thmb": 18,
                "rpoint": 14, "rmid": 9, "rb": 7, "rpin": 5
            },
            "finger_comparison_1.png"
        ),
        (  # Тест 2
            {
                "lpin": 3, "lb": 6, "lmid": 9, "lpoint": 11, "thmb": 15,
                "rpoint": 12, "rmid": 7, "rb": 5, "rpin": 4
            },
            {
                "lpin": 4, "lb": 7, "lmid": 8, "lpoint": 10, "thmb": 14,
                "rpoint": 13, "rmid": 8, "rb": 6, "rpin": 5
            },
            "finger_comparison_2.png"
        ),
        (  # Тест 3
            {
                "lpin": 2, "lb": 4, "lmid": 6, "lpoint": 8, "thmb": 10,
                "rpoint": 9, "rmid": 7, "rb": 3, "rpin": 2
            },
            {
                "lpin": 3, "lb": 5, "lmid": 7, "lpoint": 9, "thmb": 11,
                "rpoint": 8, "rmid": 6, "rb": 4, "rpin": 3
            },
            "finger_comparison_3.png"
        ),
        (  # Тест 4
            {
                "lpin": 4, "lb": 6, "lmid": 8, "lpoint": 10, "thmb": 12,
                "rpoint": 13, "rmid": 9, "rb": 7, "rpin": 5
            },
            {
                "lpin": 5, "lb": 7, "lmid": 9, "lpoint": 11, "thmb": 13,
                "rpoint": 14, "rmid": 10, "rb": 8, "rpin": 6
            },
            "finger_comparison_4.png"
        ),
        (  # Тест 5
            {
                "lpin": 1, "lb": 3, "lmid": 5, "lpoint": 7, "thmb": 9,
                "rpoint": 8, "rmid": 6, "rb": 4, "rpin": 2
            },
            {
                "lpin": 2, "lb": 4, "lmid": 6, "lpoint": 8, "thmb": 10,
                "rpoint": 9, "rmid": 7, "rb": 5, "rpin": 3
            },
            "finger_comparison_5.png"
        ),
    ]
    
    # Запись тестов в файл
    with open("drawgist_test.txt", "w", encoding="utf-8") as file:
        for i, (qwerty_data, zubachew_data, filename) in enumerate(test_cases, 1):
            file.write(f"Тест {i}:\n")
            file.write(f"Данные для QWERTY: {qwerty_data}\n")
            file.write(f"Данные для Zubachew: {zubachew_data}\n")
            file.write(f"Рисунок сохранён как: {filename}\n")
            file.write("-" * 40 + "\n")
            # Вызов функции draw_gist для каждого теста
            draw_gist(qwerty_data, zubachew_data, filename)
    
    print("Все графики сохранены и результаты записаны в файл drawgist_test.txt")

# Запуск тестов
test_draw_gist()
