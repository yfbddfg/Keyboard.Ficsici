def check_file(t):
    if (t == ''):
        return 2
#    print(t)
    return t

with open("test.txt", "r") as file:
    while True:
        str_read = file.readline()
        if (check_file(str_read) == 2):
            break
        else:
            print(str_read)
file.close()


