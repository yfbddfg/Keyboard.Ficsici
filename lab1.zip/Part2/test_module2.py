a = True
if not a:
    print("ha")
if a:
    print("haha")

